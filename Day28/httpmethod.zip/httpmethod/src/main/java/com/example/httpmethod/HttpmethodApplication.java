package com.example.httpmethod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpmethodApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpmethodApplication.class, args);
	}

}
