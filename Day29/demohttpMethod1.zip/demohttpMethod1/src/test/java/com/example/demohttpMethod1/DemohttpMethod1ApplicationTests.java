package com.example.demohttpMethod1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemohttpMethod1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
