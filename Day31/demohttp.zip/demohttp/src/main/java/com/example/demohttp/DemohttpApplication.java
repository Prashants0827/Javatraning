package com.example.demohttp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemohttpApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemohttpApplication.class, args);
	}

}
